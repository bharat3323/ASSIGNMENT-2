#Take a number from the user and check whether it is present in the list. If it's in the list, print "Available."
list=[10,20,30,40,50,60]
num=int(input("Enter the element: "))
if num in list:
    print(num,"its in the list ,available")
else:
    print("not available")