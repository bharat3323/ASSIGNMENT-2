#Write a program that checks if a given number is odd using the "if" statement.
num=int(input("Enter the number: "))
if(num%2==1):
    print(num,"number is odd")
else:
    print("No Output")