#Take Two character from user check if the ascii value both of character are odd then print the sum of ascii values of character
char1=input("Enter the char1: ")
char2=input("Enter the char2: ")
a=ord(char1)
if(a%2==1 & a%2==1):
    sum=a+a
    print("sum is",sum)
else:
    print("no Output")