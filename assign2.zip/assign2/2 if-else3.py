#Take two numbers from users and print the sum of those numbers if the sum is even.
num1=int(input("Enter the num1: "))
num2=int(input("Enter the num2: "))
result=num1+num2
if(result%2==0):
    print("Sum of two number is :",result)
else:
    print("No output")