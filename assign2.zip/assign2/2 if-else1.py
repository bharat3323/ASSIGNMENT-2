#WAP to check numbers are divisible by 4 and 5 Print those numbers
num=int(input("Enter the the number: "))
if(num%4==0 and num%5==0):
    print(num,"number is divisible by 4 and 5")
else:
    print(num,"number is not divisible by 4 and 5")