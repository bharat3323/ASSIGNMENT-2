#WAP to determine whether entered angles define a right-angled triangle.Take three values of angle from the user.
angel1=int(input("Enter the angel:"))
angel2=int(input("Enter the ange2:"))
angel3=int(input("Enter the ange3:"))
if(angel1+angel2+angel3==180):##a+b=c(ptg thm)
    print("Angel is Right angel")      
else:
    print("Angel is not Right angel")