#Take the number from user and modulus with 8 if the reminder of the number is 3 then print reminder.
num=int(input("Enter the number: "))
if (num%8==3):
    print("remainder is 3")
else:
    print("No output")