#Take single character from user check if the ascii value of character is Even the print character.
char=(input("Enter the character: "))
a=ord(char)######ord(char)-------returns integer representingthe unicode char
if(a%2==0):
    print(char,"even value",a)
else:
    print("No Output")