#Take two numbers from the user, check if both are odd and then print the sum of the numbers.
num1=int(input("Enter the Num: "))
num2=int(input("Enter the Num: "))
if (num1%2==1 and num2%2==1):
    sum=num1+num2
    print(sum)
else:
    print("no output")