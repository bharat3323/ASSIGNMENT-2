#Print the "Core2web" string a number of times entered by the user if the number is even.
string="core2web"
num=int(input("Enter the number: "))
if(num%2==0):
    for num in range(num):
        print(string)
else:
    print("no output")